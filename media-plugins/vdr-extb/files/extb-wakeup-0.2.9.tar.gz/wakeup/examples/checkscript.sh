#!/bin/bash
  
pgrep noad >/dev/null 2>&1       && { echo "Noad l�uft";  exit; }

USERCOUNT=`who | wc -l`;
test $5 -eq 0 -a $USERCOUNT -gt 0 && { echo "$USERCOUNT Nutzer sind eingeloggt."; exit; }
